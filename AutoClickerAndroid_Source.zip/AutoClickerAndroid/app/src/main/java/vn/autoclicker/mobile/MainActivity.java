package vn.autoclicker.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private LinearLayout presetList;
    private TextView status;
    private EditText nameInput;
    private EditText intervalInput;
    private EditText roundPauseInput;
    private String selectedMode = PresetStore.MODE_SEQUENCE;
    private Button sequenceButton;
    private Button simultaneousButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(40));
        scroll.addView(root);

        TextView title = text("AUTO CLICKER", 26, true);
        root.addView(title);
        root.addView(text("Bấm đơn • đa điểm • lưu bộ nút bấm", 15, false));

        status = text("", 15, true);
        status.setPadding(0, dp(18), 0, dp(10));
        root.addView(status);

        Button access = button("1. MỞ CÀI ĐẶT TRỢ NĂNG");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        Button panel = button("2. HIỆN THANH ĐIỀU KHIỂN NỔI");
        panel.setOnClickListener(v -> {
            AutoClickAccessibilityService s = AutoClickAccessibilityService.getInstance();
            if (s == null) {
                Toast.makeText(this, "Hãy bật Auto Clicker trong Trợ năng trước", Toast.LENGTH_LONG).show();
            } else {
                s.showPanel();
                Toast.makeText(this, "Thanh điều khiển đang hiển thị", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(panel);

        root.addView(section("Chế độ bấm"));
        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        sequenceButton = compactButton("Tuần tự");
        simultaneousButton = compactButton("Đồng thời");
        modeRow.addView(sequenceButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        modeRow.addView(simultaneousButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        sequenceButton.setOnClickListener(v -> { selectedMode = PresetStore.MODE_SEQUENCE; updateModeButtons(); });
        simultaneousButton.setOnClickListener(v -> { selectedMode = PresetStore.MODE_SIMULTANEOUS; updateModeButtons(); });
        root.addView(modeRow);

        root.addView(section("Tốc độ"));
        intervalInput = numberInput("Khoảng cách giữa các điểm (ms)", String.valueOf(PresetStore.getInterval(this)));
        roundPauseInput = numberInput("Nghỉ sau mỗi vòng (ms)", String.valueOf(PresetStore.getRoundPause(this)));
        root.addView(intervalInput);
        root.addView(roundPauseInput);

        Button timing = button("ÁP DỤNG TỐC ĐỘ");
        timing.setOnClickListener(v -> applyTiming());
        root.addView(timing);

        root.addView(section("Lưu bộ nút bấm"));
        nameInput = new EditText(this);
        nameInput.setHint("Tên bộ nút, ví dụ: Farm 1");
        nameInput.setSingleLine(true);
        root.addView(nameInput);

        Button save = button("LƯU BỘ HIỆN TẠI");
        save.setOnClickListener(v -> saveCurrent());
        root.addView(save);

        root.addView(section("Các bộ đã lưu"));
        presetList = new LinearLayout(this);
        presetList.setOrientation(LinearLayout.VERTICAL);
        root.addView(presetList);

        TextView help = text("Cách dùng: bật Trợ năng → ra màn hình cần thao tác → nhấn + để thêm điểm → kéo các số 1, 2, 3… vào vị trí cần bấm → ▶ để chạy → ■ để dừng. Một điểm = bấm đơn. Nhiều điểm có thể chọn tuần tự hoặc đồng thời trong màn hình chính.", 14, false);
        help.setPadding(0, dp(22), 0, 0);
        root.addView(help);
        return scroll;
    }

    private void applyTiming() {
        try {
            long interval = Math.max(25, Long.parseLong(intervalInput.getText().toString().trim()));
            long pause = Math.max(0, Long.parseLong(roundPauseInput.getText().toString().trim()));
            PresetStore.saveSettings(this, interval, pause, selectedMode);
            AutoClickAccessibilityService s = AutoClickAccessibilityService.getInstance();
            if (s != null) s.setSettings(interval, pause, selectedMode);
            Toast.makeText(this, "Đã áp dụng tốc độ", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Giá trị tốc độ không hợp lệ", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveCurrent() {
        AutoClickAccessibilityService s = AutoClickAccessibilityService.getInstance();
        if (s == null) {
            Toast.makeText(this, "Trợ năng chưa bật", Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayList<TapPoint> points = s.getPointsCopy();
        if (points.isEmpty()) {
            Toast.makeText(this, "Chưa có điểm bấm nào", Toast.LENGTH_SHORT).show();
            return;
        }
        String name = nameInput.getText().toString().trim();
        if (name.isEmpty()) name = "Bộ " + (PresetStore.load(this).size() + 1);
        PresetStore.upsert(this, new PresetStore.Preset(name, points, s.getIntervalMs(), s.getRoundPauseMs(), s.getTapMode()));
        nameInput.setText("");
        refreshPresets();
        Toast.makeText(this, "Đã lưu: " + name, Toast.LENGTH_SHORT).show();
    }

    private void refresh() {
        boolean on = AutoClickAccessibilityService.getInstance() != null;
        status.setText(on ? "● Trợ năng: ĐÃ BẬT" : "● Trợ năng: CHƯA BẬT");
        status.setTextColor(on ? Color.rgb(25, 118, 60) : Color.rgb(190, 40, 40));
        selectedMode = PresetStore.getMode(this);
        updateModeButtons();
        if (intervalInput != null) intervalInput.setText(String.valueOf(PresetStore.getInterval(this)));
        if (roundPauseInput != null) roundPauseInput.setText(String.valueOf(PresetStore.getRoundPause(this)));
        refreshPresets();
    }

    private void refreshPresets() {
        if (presetList == null) return;
        presetList.removeAllViews();
        ArrayList<PresetStore.Preset> all = PresetStore.load(this);
        if (all.isEmpty()) {
            presetList.addView(text("Chưa có bộ nào được lưu.", 14, false));
            return;
        }
        for (PresetStore.Preset p : all) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(6), 0, dp(6));

            String modeLabel = PresetStore.MODE_SIMULTANEOUS.equals(p.mode) ? "đồng thời" : "tuần tự";
            TextView name = text(p.name + "  •  " + p.points.size() + " điểm • " + modeLabel, 15, true);
            row.addView(name, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

            Button load = compactButton("Nạp");
            load.setOnClickListener(v -> {
                AutoClickAccessibilityService s = AutoClickAccessibilityService.getInstance();
                if (s == null) Toast.makeText(this, "Hãy bật Trợ năng trước", Toast.LENGTH_SHORT).show();
                else s.loadPreset(p);
            });
            row.addView(load);

            Button del = compactButton("Xóa");
            del.setOnClickListener(v -> { PresetStore.delete(this, p.name); refreshPresets(); });
            row.addView(del);
            presetList.addView(row);
        }
    }

    private void updateModeButtons() {
        if (sequenceButton == null || simultaneousButton == null) return;
        boolean sequence = PresetStore.MODE_SEQUENCE.equals(selectedMode);
        sequenceButton.setEnabled(!sequence);
        simultaneousButton.setEnabled(sequence);
    }

    private TextView section(String s) {
        TextView v = text(s, 18, true);
        v.setPadding(0, dp(24), 0, dp(8));
        return v;
    }

    private EditText numberInput(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        lp.setMargins(0, dp(5), 0, dp(5));
        b.setLayoutParams(lp);
        return b;
    }

    private Button compactButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        return b;
    }

    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(Color.rgb(35, 35, 35));
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }
}
