package vn.autoclicker.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class AutoClickAccessibilityService extends AccessibilityService {
    private static AutoClickAccessibilityService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<TapPoint> points = new ArrayList<>();
    private final ArrayList<View> markerViews = new ArrayList<>();
    private final ArrayList<WindowManager.LayoutParams> markerParams = new ArrayList<>();

    private WindowManager wm;
    private LinearLayout panel;
    private WindowManager.LayoutParams panelParams;
    private boolean running = false;
    private int clickIndex = 0;
    private long intervalMs = 120;
    private long roundPauseMs = 300;
    private String tapMode = PresetStore.MODE_SEQUENCE;
    private int markerSizePx;

    public static AutoClickAccessibilityService getInstance() {
        return instance;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        markerSizePx = dp(52);
        intervalMs = PresetStore.getInterval(this);
        roundPauseMs = PresetStore.getRoundPause(this);
        tapMode = PresetStore.getMode(this);
        showPanel();
    }

    @Override
    public void onDestroy() {
        stopClicking();
        removeAllOverlays();
        instance = null;
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event) {}
    @Override public void onInterrupt() { stopClicking(); }

    public synchronized ArrayList<TapPoint> getPointsCopy() {
        ArrayList<TapPoint> copy = new ArrayList<>();
        for (TapPoint p : points) copy.add(new TapPoint(p.x, p.y));
        return copy;
    }

    public long getIntervalMs() { return intervalMs; }
    public long getRoundPauseMs() { return roundPauseMs; }
    public String getTapMode() { return tapMode; }

    public void setSettings(long interval, long roundPause, String mode) {
        intervalMs = Math.max(25, interval);
        roundPauseMs = Math.max(0, roundPause);
        tapMode = PresetStore.MODE_SIMULTANEOUS.equals(mode) ? PresetStore.MODE_SIMULTANEOUS : PresetStore.MODE_SEQUENCE;
        PresetStore.saveSettings(this, intervalMs, roundPauseMs, tapMode);
    }

    public void loadPreset(PresetStore.Preset preset) {
        stopClicking();
        clearPoints();
        setSettings(preset.intervalMs, preset.roundPauseMs, preset.mode);
        for (TapPoint p : preset.points) addPointAt(p.x, p.y);
        Toast.makeText(this, "Đã nạp: " + preset.name, Toast.LENGTH_SHORT).show();
    }

    public void showPanel() {
        if (wm == null || panel != null) return;

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        panel.setPadding(dp(6), dp(4), dp(6), dp(4));
        panel.setBackgroundColor(Color.argb(220, 32, 33, 36));

        Button add = smallButton("+");
        Button play = smallButton("▶");
        Button stop = smallButton("■");
        Button save = smallButton("💾");
        Button clear = smallButton("×");

        panel.addView(add); panel.addView(play); panel.addView(stop); panel.addView(save); panel.addView(clear);

        panelParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(12);
        panelParams.y = dp(80);

        panel.setOnTouchListener(new DragTouchListener(panelParams, panel));
        add.setOnClickListener(v -> addPointAt(dp(120) + points.size() * dp(12), dp(240) + points.size() * dp(12)));
        play.setOnClickListener(v -> startClicking());
        stop.setOnClickListener(v -> stopClicking());
        clear.setOnClickListener(v -> { stopClicking(); clearPoints(); });
        save.setOnClickListener(v -> quickSave());

        wm.addView(panel, panelParams);
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setMinWidth(dp(44));
        b.setMinimumWidth(dp(44));
        b.setMinHeight(dp(42));
        b.setMinimumHeight(dp(42));
        b.setPadding(0, 0, 0, 0);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    public void addPointAt(int centerX, int centerY) {
        if (wm == null) return;
        final int index = points.size();
        TapPoint point = new TapPoint(Math.max(0, centerX), Math.max(0, centerY));
        points.add(point);

        TextView marker = new TextView(this);
        marker.setText(String.valueOf(index + 1));
        marker.setTextColor(Color.WHITE);
        marker.setTextSize(18);
        marker.setGravity(Gravity.CENTER);
        marker.setBackground(createCircleDrawable(Color.argb(205, 30, 136, 229)));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                markerSizePx,
                markerSizePx,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = point.x - markerSizePx / 2;
        lp.y = point.y - markerSizePx / 2;

        marker.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (running) return true;
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX(); downY = e.getRawY(); startX = lp.x; startY = lp.y; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.x = startX + Math.round(e.getRawX() - downX);
                    lp.y = startY + Math.round(e.getRawY() - downY);
                    wm.updateViewLayout(v, lp);
                    point.x = lp.x + markerSizePx / 2;
                    point.y = lp.y + markerSizePx / 2;
                    return true;
                }
                return true;
            }
        });

        markerViews.add(marker);
        markerParams.add(lp);
        wm.addView(marker, lp);
    }

    private android.graphics.drawable.GradientDrawable createCircleDrawable(int color) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(dp(2), Color.WHITE);
        return d;
    }

    public void clearPoints() {
        if (wm == null) return;
        for (View v : markerViews) {
            try { wm.removeView(v); } catch (Exception ignored) {}
        }
        markerViews.clear();
        markerParams.clear();
        points.clear();
    }

    private void setMarkersTouchable(boolean touchable) {
        for (int i = 0; i < markerViews.size(); i++) {
            WindowManager.LayoutParams lp = markerParams.get(i);
            if (touchable) {
                lp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                markerViews.get(i).setAlpha(1f);
            } else {
                lp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                markerViews.get(i).setAlpha(0.55f);
            }
            try { wm.updateViewLayout(markerViews.get(i), lp); } catch (Exception ignored) {}
        }
    }

    public void startClicking() {
        if (running) return;
        if (points.isEmpty()) {
            Toast.makeText(this, "Hãy thêm ít nhất 1 điểm bấm", Toast.LENGTH_SHORT).show();
            return;
        }
        running = true;
        clickIndex = 0;
        setMarkersTouchable(false);
        handler.post(clickLoop);
    }

    public void stopClicking() {
        running = false;
        handler.removeCallbacks(clickLoop);
        if (wm != null) setMarkersTouchable(true);
    }

    private final Runnable clickLoop = new Runnable() {
        @Override public void run() {
            if (!running || points.isEmpty()) return;
            if (PresetStore.MODE_SIMULTANEOUS.equals(tapMode)) {
                performSimultaneousTap();
                handler.postDelayed(this, Math.max(25, roundPauseMs));
                return;
            }
            if (clickIndex >= points.size()) clickIndex = 0;
            TapPoint p = points.get(clickIndex);
            performTap(p.x, p.y);
            clickIndex++;
            long delay = (clickIndex >= points.size()) ? roundPauseMs : intervalMs;
            handler.postDelayed(this, Math.max(25, delay));
        }
    };

    private void performSimultaneousTap() {
        int max = GestureDescription.getMaxStrokeCount();
        GestureDescription.Builder builder = new GestureDescription.Builder();
        int count = Math.min(points.size(), max);
        for (int i = 0; i < count; i++) {
            TapPoint p = points.get(i);
            Path path = new Path();
            path.moveTo(p.x, p.y);
            builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 35));
        }
        if (count > 0) dispatchGesture(builder.build(), null, null);
        if (points.size() > max) {
            Toast.makeText(this, "Chế độ đồng thời chỉ dùng tối đa " + max + " điểm trên thiết bị này", Toast.LENGTH_SHORT).show();
        }
    }

    private void performTap(int x, int y) {
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 35);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture, null, null);
    }

    private void quickSave() {
        if (points.isEmpty()) {
            Toast.makeText(this, "Không có điểm để lưu", Toast.LENGTH_SHORT).show();
            return;
        }
        String name = "Nhanh " + new SimpleDateFormat("dd-MM HH:mm:ss", Locale.getDefault()).format(new Date());
        PresetStore.upsert(this, new PresetStore.Preset(name, getPointsCopy(), intervalMs, roundPauseMs, tapMode));
        Toast.makeText(this, "Đã lưu bộ nút: " + name, Toast.LENGTH_SHORT).show();
    }

    private void removeAllOverlays() {
        clearPoints();
        if (panel != null && wm != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        panel = null;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private class DragTouchListener implements View.OnTouchListener {
        private final WindowManager.LayoutParams lp;
        private final View view;
        private float downX, downY;
        private int startX, startY;

        DragTouchListener(WindowManager.LayoutParams lp, View view) {
            this.lp = lp; this.view = view;
        }

        @Override public boolean onTouch(View v, MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = e.getRawX(); downY = e.getRawY(); startX = lp.x; startY = lp.y;
                return false;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                if (Math.abs(dx) + Math.abs(dy) > dp(6)) {
                    lp.x = startX + Math.round(dx); lp.y = startY + Math.round(dy);
                    wm.updateViewLayout(view, lp);
                    return true;
                }
            }
            return false;
        }
    }
}
