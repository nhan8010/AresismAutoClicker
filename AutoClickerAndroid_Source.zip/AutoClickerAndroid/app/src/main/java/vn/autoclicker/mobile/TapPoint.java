package vn.autoclicker.mobile;

import org.json.JSONException;
import org.json.JSONObject;

public class TapPoint {
    public int x;
    public int y;

    public TapPoint(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("x", x);
        o.put("y", y);
        return o;
    }

    public static TapPoint fromJson(JSONObject o) {
        return new TapPoint(o.optInt("x", 0), o.optInt("y", 0));
    }
}
