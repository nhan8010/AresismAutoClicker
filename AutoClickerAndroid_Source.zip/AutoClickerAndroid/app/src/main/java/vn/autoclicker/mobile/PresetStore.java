package vn.autoclicker.mobile;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class PresetStore {
    private static final String PREF = "auto_clicker_prefs";
    private static final String KEY_PRESETS = "presets";
    private static final String KEY_INTERVAL = "interval_ms";
    private static final String KEY_ROUND_PAUSE = "round_pause_ms";
    private static final String KEY_MODE = "tap_mode";

    public static final String MODE_SEQUENCE = "sequence";
    public static final String MODE_SIMULTANEOUS = "simultaneous";

    private PresetStore() {}

    public static class Preset {
        public final String name;
        public final ArrayList<TapPoint> points;
        public final long intervalMs;
        public final long roundPauseMs;
        public final String mode;

        public Preset(String name, List<TapPoint> points, long intervalMs, long roundPauseMs, String mode) {
            this.name = name;
            this.points = new ArrayList<>();
            for (TapPoint p : points) this.points.add(new TapPoint(p.x, p.y));
            this.intervalMs = intervalMs;
            this.roundPauseMs = roundPauseMs;
            this.mode = MODE_SIMULTANEOUS.equals(mode) ? MODE_SIMULTANEOUS : MODE_SEQUENCE;
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static long getInterval(Context c) {
        return Math.max(25, prefs(c).getLong(KEY_INTERVAL, 120));
    }

    public static long getRoundPause(Context c) {
        return Math.max(0, prefs(c).getLong(KEY_ROUND_PAUSE, 300));
    }

    public static String getMode(Context c) {
        String m = prefs(c).getString(KEY_MODE, MODE_SEQUENCE);
        return MODE_SIMULTANEOUS.equals(m) ? MODE_SIMULTANEOUS : MODE_SEQUENCE;
    }

    public static void saveSettings(Context c, long interval, long roundPause, String mode) {
        prefs(c).edit()
                .putLong(KEY_INTERVAL, Math.max(25, interval))
                .putLong(KEY_ROUND_PAUSE, Math.max(0, roundPause))
                .putString(KEY_MODE, MODE_SIMULTANEOUS.equals(mode) ? MODE_SIMULTANEOUS : MODE_SEQUENCE)
                .apply();
    }

    public static ArrayList<Preset> load(Context c) {
        ArrayList<Preset> out = new ArrayList<>();
        String raw = prefs(c).getString(KEY_PRESETS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String name = o.optString("name", "Preset " + (i + 1));
                long interval = Math.max(25, o.optLong("interval", 120));
                long roundPause = Math.max(0, o.optLong("roundPause", 300));
                String mode = o.optString("mode", MODE_SEQUENCE);
                JSONArray pointsArray = o.optJSONArray("points");
                ArrayList<TapPoint> points = new ArrayList<>();
                if (pointsArray != null) {
                    for (int j = 0; j < pointsArray.length(); j++) {
                        points.add(TapPoint.fromJson(pointsArray.getJSONObject(j)));
                    }
                }
                out.add(new Preset(name, points, interval, roundPause, mode));
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static void upsert(Context c, Preset preset) {
        ArrayList<Preset> all = load(c);
        boolean replaced = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).name.equalsIgnoreCase(preset.name)) {
                all.set(i, preset);
                replaced = true;
                break;
            }
        }
        if (!replaced) all.add(preset);
        persist(c, all);
    }

    public static void delete(Context c, String name) {
        ArrayList<Preset> all = load(c);
        all.removeIf(p -> p.name.equals(name));
        persist(c, all);
    }

    private static void persist(Context c, List<Preset> all) {
        JSONArray arr = new JSONArray();
        try {
            for (Preset p : all) {
                JSONObject o = new JSONObject();
                o.put("name", p.name);
                o.put("interval", p.intervalMs);
                o.put("roundPause", p.roundPauseMs);
                o.put("mode", p.mode);
                JSONArray pa = new JSONArray();
                for (TapPoint point : p.points) pa.put(point.toJson());
                o.put("points", pa);
                arr.put(o);
            }
        } catch (JSONException ignored) {}
        prefs(c).edit().putString(KEY_PRESETS, arr.toString()).apply();
    }
}
